﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork9.Models
{
    public class MaintenanceStationContext : DbContext
    {
        public DbSet<Client> Clients { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<CarInsurance> CarInsurances { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<Mechanic> Mechanics { get; set; }

        public MaintenanceStationContext(DbContextOptions options) : base(options)
        {

        }
        public MaintenanceStationContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //if (!optionsBuilder.IsConfigured)
            //{
            //    optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=MaintenanceStation;Integrated Security=True;");
            //}
            IConfigurationRoot configuration = new ConfigurationBuilder()
            .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
            .AddJsonFile("appsettings.json")
            .Build();
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("MaintenanceStationConnectionString"));
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Client>().HasMany(i => i.Cars).WithOne(i => i.Owner);
            modelBuilder.Entity<Client>().HasMany(i => i.Services).WithOne(i => i.Client);
            modelBuilder.Entity<Service>().HasOne(i => i.Car).WithMany(i => i.Services);
            modelBuilder.Entity<Service>().HasOne(i => i.Client).WithMany(i => i.Services);
            modelBuilder.Entity<Service>().HasMany(i => i.Mechanics).WithMany(i => i.Services).UsingEntity(i => i.ToTable("MechanicsServices"));
            modelBuilder.Entity<Car>().HasOne(i => i.CarInsurance).WithOne(i => i.Car).HasForeignKey<CarInsurance>(i => i.CarId);
        }

    }
}
