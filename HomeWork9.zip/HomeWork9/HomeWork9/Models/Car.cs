﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork9.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string CarNumber { get; set; }
        public string VinCode { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public double EngineCapacity { get; set; }
        public int CurrentMileage { get; set; }
        public Client Owner { get; set; }
        public CarInsurance CarInsurance { get; set; }
        public List<Service> Services { get; set; } = new List<Service>();

    }
}
