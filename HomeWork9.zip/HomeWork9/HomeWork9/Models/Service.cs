﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork9.Models
{
    public class Service
    {
        public int Id { get; set; }
        public string ServiceNumber { get; set; }
        public bool IsPaid { get; set; }
        public DateTime ServiceDate { get; set; }
        public Client Client { get; set; }
        public Car Car { get; set; }
        public List<Mechanic> Mechanics { get; set; } = new List<Mechanic>();

    }
}
