﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork9.Models
{
    public class CarInsurance
    {
        public int Id { get; set; }
        public string SerialNumber { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int? CarId { get; set; }
        public Car Car { get; set; }

    }
}
