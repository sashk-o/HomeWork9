﻿using HomeWork9.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork9
{
    class MyContextFactory : IDesignTimeDbContextFactory<MaintenanceStationContext>
    {
        public MaintenanceStationContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<MaintenanceStationContext>();
            optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=MaintenanceStation;Integrated Security=True;");

            return new MaintenanceStationContext(optionsBuilder.Options);
        }
    }
}
