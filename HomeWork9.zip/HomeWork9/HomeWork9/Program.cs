﻿using HomeWork9.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace HomeWork9
{
    class Program
    {
        static async Task Main(string[] args)
        {
            /*using (var dbContext = new MaintenanceStationContext())
            {
                var FirstClient = new Client
                {
                    FirstName = "Tom",
                    LastName = "Felton",
                    Birthday = new DateTime(2000, 10, 12),
                    Gender = "Male",
                    PhoneNumber = "3801231215",
                    EMail = "me-mail@gmail.com",
                    Address = "City-17"
                };
                var SecondClient = new Client
                {
                    FirstName = "Sarah",
                    LastName = "Connor",
                    Birthday = new DateTime(2002, 2, 22),
                    Gender = "Female",
                    PhoneNumber = "3804568925",
                    EMail = "fe-mail@gmail.com",
                    Address = "New York"
                };
                
                var FirstCar = new Car
                {
                    CarNumber = "AA3234BB",
                    VinCode = "12345678901234",
                    CurrentMileage = 100000,
                    EngineCapacity = 2.0,
                    Manufacturer = "Mercedes",
                    Model = "C200",
                    Owner = FirstClient
                };
                var SecondCar = new Car
                {
                    CarNumber = "AA1213AA",
                    VinCode = "98765432109876",
                    CurrentMileage = 150000,
                    EngineCapacity = 2.0,
                    Manufacturer = "BMW",
                    Model = "520d",
                    Owner = SecondClient
                };
                
                var FirstMechanic = new Mechanic
                {
                    FirstName = "First",
                    LastName = "Mechanic",
                    EmploymentDate = DateTime.Today,
                    StillEmployed = true
                };
                var SecondMechanic = new Mechanic
                {
                    FirstName = "Second",
                    LastName = "Mechanic",
                    EmploymentDate = new DateTime(2020, 8, 8),
                    StillEmployed = false
                };
                
                var FirstCarInsurance = new CarInsurance
                {
                    SerialNumber = "CM123456",
                    ExpiryDate = DateTime.Today,
                    Car = FirstCar,
                    CarId = FirstCar.Id
                };
                var SecondCarInsurance = new CarInsurance
                {
                    SerialNumber = "EA789654",
                    ExpiryDate = DateTime.Today,
                    Car = SecondCar,
                    CarId = SecondCar.Id
                };

                var FirstService = new Service
                {
                    ServiceNumber = "Dec122020-1505",
                    Car = FirstCar,
                    Client = FirstClient,
                    IsPaid = true,
                    ServiceDate = new DateTime(2020, 12, 12),
                    Mechanics = new List<Mechanic> { FirstMechanic, SecondMechanic }
                };
                var SecondService = new Service
                {
                    ServiceNumber = "Jul312021-1215",
                    Car = SecondCar,
                    Client = SecondClient,
                    IsPaid = false,
                    ServiceDate = new DateTime(2021, 7, 31),
                    Mechanics = new List<Mechanic> { FirstMechanic, SecondMechanic }
                };
                
                FirstClient.Cars = new List<Car> { FirstCar };
                FirstClient.Services = new List<Service> { FirstService };
                SecondClient.Cars = new List<Car> { SecondCar };
                SecondClient.Services = new List<Service> { SecondService };

                FirstCar.Services = new List<Service> { FirstService };
                FirstCar.CarInsurance = FirstCarInsurance;
                SecondCar.Services = new List<Service> { SecondService };
                SecondCar.CarInsurance = SecondCarInsurance;

                FirstMechanic.Services = new List<Service> { FirstService, SecondService };
                SecondMechanic.Services = new List<Service> { SecondService };

                dbContext.Clients.AddRange(FirstClient, SecondClient);
                dbContext.Cars.AddRange(FirstCar, SecondCar);
                dbContext.Mechanics.AddRange(FirstMechanic, SecondMechanic);
                dbContext.CarInsurances.AddRange(FirstCarInsurance, SecondCarInsurance);
                dbContext.Services.AddRange(FirstService, SecondService);

                dbContext.SaveChanges();
            }*/
            using (var dbContext = new MaintenanceStationContext())
            {
                var clients = await dbContext.Clients.ToListAsync();
                foreach (var client in clients)
                {
                    Console.WriteLine($"FirstName: {client.FirstName}\nLastName: {client.LastName}\nGender: {client.Gender}\n" +
                        $"Birthday: {client.Birthday}\nAddress: {client.Address}\nEMail: {client.EMail}\n" +
                        $"PhoneNumber: {client.PhoneNumber}\nCars: {client.Cars.Count}\nServices: {client.Services.Count}\n");
                }
            }
            using (var dbContext = new MaintenanceStationContext())
            {
                var car = await dbContext.Cars.FirstOrDefaultAsync();
                Console.WriteLine($"CurrentMileage before changing: {car.CurrentMileage}");
                car.CurrentMileage += 10000;
                Console.WriteLine($"CurrentMileage after changing: {car.CurrentMileage}");
                dbContext.SaveChanges();
            }
            using (var dbContext = new MaintenanceStationContext())
            {
                var mechanic = new Mechanic
                {
                    FirstName = "Test",
                    LastName = "Test",
                    EmploymentDate = DateTime.Now,
                    StillEmployed = true,
                    Services = new List<Service>()
                };
                dbContext.Mechanics.Add(mechanic);
                dbContext.SaveChanges();
            }
            using (var dbContext = new MaintenanceStationContext())
            {
                var mechanic = await dbContext.Mechanics.SingleAsync(i => i.FirstName == "Test");
                if (mechanic != null)
                {
                    dbContext.Mechanics.Remove(mechanic);
                }
                dbContext.SaveChanges();
            }
            Console.ReadLine();
        }
    }
}