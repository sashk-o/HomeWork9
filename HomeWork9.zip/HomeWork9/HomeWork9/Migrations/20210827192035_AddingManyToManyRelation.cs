﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HomeWork9.Migrations
{
    public partial class AddingManyToManyRelation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MechanicService_Mechanics_MechanicsId",
                table: "MechanicService");

            migrationBuilder.DropForeignKey(
                name: "FK_MechanicService_Services_ServicesId",
                table: "MechanicService");

            migrationBuilder.DropPrimaryKey(
                name: "PK_MechanicService",
                table: "MechanicService");

            migrationBuilder.RenameTable(
                name: "MechanicService",
                newName: "MechanicsServices");

            migrationBuilder.RenameIndex(
                name: "IX_MechanicService_ServicesId",
                table: "MechanicsServices",
                newName: "IX_MechanicsServices_ServicesId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_MechanicsServices",
                table: "MechanicsServices",
                columns: new[] { "MechanicsId", "ServicesId" });

            migrationBuilder.AddForeignKey(
                name: "FK_MechanicsServices_Mechanics_MechanicsId",
                table: "MechanicsServices",
                column: "MechanicsId",
                principalTable: "Mechanics",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MechanicsServices_Services_ServicesId",
                table: "MechanicsServices",
                column: "ServicesId",
                principalTable: "Services",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MechanicsServices_Mechanics_MechanicsId",
                table: "MechanicsServices");

            migrationBuilder.DropForeignKey(
                name: "FK_MechanicsServices_Services_ServicesId",
                table: "MechanicsServices");

            migrationBuilder.DropPrimaryKey(
                name: "PK_MechanicsServices",
                table: "MechanicsServices");

            migrationBuilder.RenameTable(
                name: "MechanicsServices",
                newName: "MechanicService");

            migrationBuilder.RenameIndex(
                name: "IX_MechanicsServices_ServicesId",
                table: "MechanicService",
                newName: "IX_MechanicService_ServicesId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_MechanicService",
                table: "MechanicService",
                columns: new[] { "MechanicsId", "ServicesId" });

            migrationBuilder.AddForeignKey(
                name: "FK_MechanicService_Mechanics_MechanicsId",
                table: "MechanicService",
                column: "MechanicsId",
                principalTable: "Mechanics",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MechanicService_Services_ServicesId",
                table: "MechanicService",
                column: "ServicesId",
                principalTable: "Services",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
